# MyST Markdown — Complete Syntax Reference

Comprehensive reference for writing book chapters in MyST Markdown.
Docs: https://mystmd.org/guide

---

## Page Frontmatter

Every `.md` file starts with YAML frontmatter between `---` delimiters.

### Chapter-Level Attributes

```yaml
---
title: "Chapter Title"
subtitle: "Optional subtitle"
short_title: "Short Nav Title"       # max 40 chars, used in navigation
description: |
  A brief summary of this chapter for previews and SEO.
label: ch-unique-label               # for cross-referencing this page
date: 2026-02-11
tags:
  - machine-learning
  - tutorial
keywords:
  - neural networks
  - deep learning
thumbnail: ../images/ch01-thumb.png
banner: ../images/ch01-banner.png
authors:
  - name: Author Name
    email: author@example.com
    orcid: 0000-0002-1234-5678
    affiliations:
      - University Name
    roles:
      - Writing – original draft
numbering:
  heading_1: true
  heading_2: true
  heading_3: true
math:
  # Reusable LaTeX macros for this page
  '\ddt': '\frac{d}{dt}'
  '\bold': '\mathbf{#1}'
exports:
  - format: pdf
    template: plain_latex_book
    output: exports/chapter.pdf
parts:
  abstract: |
    Optional abstract for this chapter.
---
```

### Project-Level Attributes (myst.yml)

```yaml
version: 1
project:
  title: "Book Title"
  subtitle: "Book Subtitle"
  authors:
    - name: Author Name
      orcid: 0000-0002-1234-5678
      email: author@example.com
      affiliations:
        - id: fau
          institution: Florida Atlantic University
          department: Computer Science
  description: "Book description for SEO and previews"
  keywords: [AI, education, machine learning]
  license: CC-BY-4.0
  open_access: true
  copyright: "© 2026 Author Name"
  subject: "Computer Science"
  doi: 10.xxxx/xxxxx
  github: https://github.com/liquid-books/book-slug
  bibliography:
    - references.bib
  numbering:
    heading_1: true
    heading_2: true
    heading_3: true
    figure: true
    table: true
    equation: true
  math:
    '\RR': '\mathbb{R}'
    '\NN': '\mathbb{N}'
  abbreviations:
    AI: Artificial Intelligence
    ML: Machine Learning
    NLP: Natural Language Processing
  toc:
    - file: index.md
    - title: "Part I: Foundations"
      children:
        - file: chapters/ch01-intro.md
        - file: chapters/ch02-basics.md
    - title: "Part II: Advanced Topics"
      children:
        - file: chapters/ch03-advanced.md

site:
  title: "Book Title"
```

---

## Typography (CommonMark + MyST)

```markdown
# Heading 1
## Heading 2
### Heading 3

**bold**  *italic*  ***bold italic***
~~strikethrough~~  `inline code`

> Blockquote
> Multiple lines

- Unordered list
  - Nested item
1. Ordered list
2. Second item

[Link text](https://example.com)
![Alt text](./images/photo.png "Optional title")

Horizontal rule:
---

Line break: end line with two spaces  
or use a backslash\
```

### Extended Typography

```markdown
Term
: Definition of the term

Footnote reference[^1]
[^1]: Footnote content here.

{abbr}`MyST (Markedly Structured Text)` — hover shows expansion
{sub}`subscript`
{sup}`superscript`
{sc}`Small Caps Text`
{kbd}`Ctrl+C`
{del}`deleted text`
{u}`underlined text`
```

---

## Directives (Block-Level)

General syntax:
````markdown
:::{directive-name} argument
:option1: value
:option2: value

Body content here.
:::
````

Or with backticks:
````markdown
```{directive-name} argument
:option1: value

Body content
```
````

### Admonitions / Callouts

Available kinds: `note`, `tip`, `warning`, `danger`, `error`, `important`, `hint`, `caution`, `attention`, `seealso`

```markdown
:::{note} Custom Title
Body text with **markdown** support.
:::

:::{tip}
:class: dropdown
This content is hidden until clicked.
:::

:::{warning}
:label: my-warning
:class: simple
Icon-less simple style warning.
:::

:::{danger} ⚠️ Critical Warning
:open: true
Dropdown that starts open.
:::
```

### Figures and Images

```markdown
:::{figure} ./images/my-figure.png
:label: fig-my-figure
:alt: Description for accessibility
:width: 80%
:align: center

This is the figure caption. It supports **markdown**.
:::

:::{image} ./images/decorative.png
:width: 300px
:align: right
:alt: Decorative image
:::
```

**Subfigures:**
```markdown
:::{figure}
:label: fig-comparison

![](./images/before.png)

![](./images/after.png)

Before and after comparison.
:::
```
Subfigures auto-number as Figure 1a, Figure 1b, etc.

### Code Blocks

````markdown
```{code-block} python
:caption: My Python Example
:linenos:
:emphasize-lines: 2,4

def hello():
    print("Hello, World!")
    return True
    # This line is emphasized too
```
````

With filename:
````markdown
```{code-block} javascript
:filename: app.js

const express = require('express');
```
````

### Tables

**GFM tables:**
```markdown
| Header 1 | Header 2 | Header 3 |
|:---------|:--------:|---------:|
| Left     | Center   | Right    |
| aligned  | aligned  | aligned  |
```

**With label and caption:**
```markdown
:::{table} Sales by Quarter
:label: tbl-sales

| Quarter | Revenue |
|---------|---------|
| Q1      | $1.2M   |
| Q2      | $1.5M   |
:::
```

**List table:**
```markdown
:::{list-table} Comparison
:label: tbl-compare
:header-rows: 1

* - Feature
  - Tool A
  - Tool B
* - Speed
  - Fast
  - Slow
* - Cost
  - Free
  - $99/mo
:::
```

**CSV table:**
```markdown
:::{csv-table} Data Summary
:header-rows: 1
:label: tbl-csv

Name,Age,City
Alice,30,NYC
Bob,25,LA
:::
```

### Math and Equations

**Inline:** `$E = mc^2$` or `` {math}`E = mc^2` ``

**Display equation:**
```markdown
$$
\nabla \times \mathbf{E} = -\frac{\partial \mathbf{B}}{\partial t}
$$ (eq-maxwell)
```

**Math directive:**
```markdown
:::{math}
:label: eq-schrodinger

i\hbar \frac{\partial}{\partial t} \Psi = \hat{H} \Psi
:::
```

**AMS math (align, gather, etc.):**
```markdown
\begin{align}
  x &= a + b \\
  y &= c + d
\end{align}
```

Supported AMS environments: `equation`, `multline`, `gather`, `align`, `alignat`, `flalign`, `matrix`, `pmatrix`, `bmatrix`, `Bmatrix`, `vmatrix`, `Vmatrix`, `eqnarray`

### Dropdowns

```markdown
:::{dropdown} Click to expand
:open: false

Hidden content revealed on click.
:::
```

### Cards and Grids

```markdown
::::{grid} 1 1 2 3
:::{card} Card Title 1
:link: https://example.com
Card body content.
:::

:::{card} Card Title 2
Header
^^^
Card body content with separator.
+++
Footer
:::
::::
```

### Tabs

```markdown
::::{tab-set}
:::{tab-item} Python
```python
print("Hello")
```
:::
:::{tab-item} JavaScript
```javascript
console.log("Hello");
```
:::
::::
```

### Proofs, Theorems, and Academic

```markdown
:::{prf:theorem} Pythagorean Theorem
:label: thm-pythagoras

For a right triangle with sides $a$, $b$ and hypotenuse $c$:

$$a^2 + b^2 = c^2$$
:::

:::{prf:proof}
The proof follows from... (content)
:::

:::{prf:definition} Continuity
:label: def-continuity

A function $f$ is continuous at point $a$ if...
:::
```

Available proof types: `prf:theorem`, `prf:proof`, `prf:lemma`, `prf:definition`, `prf:corollary`, `prf:axiom`, `prf:conjecture`, `prf:algorithm`, `prf:example`, `prf:remark`, `prf:property`, `prf:observation`, `prf:proposition`, `prf:assumption`, `prf:criteria`

### Exercises and Solutions

```markdown
:::{exercise} Matrix Multiplication
:label: ex-matrix

Compute the product of matrices $A$ and $B$.
:::

:::{solution} ex-matrix
:label: sol-matrix

$AB = \begin{pmatrix} ... \end{pmatrix}$
:::
```

### Diagrams (Mermaid)

```markdown
:::{mermaid}
:label: fig-flow

graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action 1]
    B -->|No| D[Action 2]
    C --> E[End]
    D --> E
:::
```

### Asides, Margins, and Sidebars

```markdown
:::{aside} Quick Note
This appears in the margin on wide screens.
:::

:::{sidebar} Related Topic
Additional context that appears alongside the main text.
:::
```

### Blockquotes with Attribution

```markdown
:::{epigraph}
The only way to do great work is to love what you do.

-- Steve Jobs
:::

:::{pull-quote}
This is a highlighted quote that stands out.
:::
```

### Glossary

```markdown
:::{glossary}
MyST
  Markedly Structured Text — a rich flavor of Markdown for technical writing.

Directive
  A block-level extension in MyST that adds special content like figures, notes, or code.
:::
```

### Include External Content

```markdown
:::{include} ../shared/common-intro.md
:::

:::{literalinclude} ../code/example.py
:language: python
:linenos:
:lines: 10-25
:emphasize-lines: 3,5
:::
```

### Embed (Reuse Content)

```markdown
:::{embed} #fig-my-figure
:::
```

### iframes (YouTube, embeds)

```markdown
:::{iframe} https://www.youtube.com/embed/dQw4w9WgXcQ
:width: 100%
:label: vid-demo
:title: Demo Video

Optional caption for the video.
:::
```

### Table of Contents (In-page)

```markdown
:::{toc}
:context: page
:depth: 2
:::
```

Contexts: `project` (all pages), `page` (headings on this page), `section` (headings in current section)

---

## Roles (Inline)

```markdown
{math}`E = mc^2`                          — inline math
{ref}`my-label`                           — cross-ref (fills in title)
{numref}`Figure %s <fig-my-figure>`       — numbered ref
{eq}`eq-maxwell`                          — equation ref
{doc}`./other-chapter.md`                 — link to page
{download}`./data/file.csv`               — downloadable file
{cite:p}`author2023`                      — parenthetical citation
{cite:t}`author2023`                      — textual citation
{abbr}`HTML (HyperText Markup Language)`  — abbreviation
{term}`MyST`                              — glossary term
{sub}`H₂O`                               — subscript
{sup}`2nd`                                — superscript
{kbd}`Ctrl+Shift+P`                       — keyboard shortcut
{sc}`Small Caps`                          — small caps
{del}`removed`                            — strikethrough
{u}`underlined`                           — underline
{button}`Click Me <https://example.com>`  — clickable button
{chem}`H2O`                               — chemical formula
{si}`9.8 m/s^2`                           — SI units
```

---

## Cross-References

### Labeling Targets

```markdown
(my-section)=
## My Section Heading

:::{figure} image.png
:label: fig-my-figure
Caption text.
:::

:::{math}
:label: eq-important
x = y + z
:::

:::{table} My Table
:label: tbl-data
| A | B |
|---|---|
| 1 | 2 |
:::
```

### Referencing

```markdown
[](#my-section)                       — auto-fills with heading text
[Custom text](#fig-my-figure)         — custom link text
[Figure {number}](#fig-my-figure)     — "Figure 3"
[{name}](#fig-my-figure)              — fills in caption text
[See Eq.](#eq-important)              — custom + link

@my-section                           — shorthand cross-ref
```

### Cross-Chapter References

Works automatically across all `.md` files in the same MyST project:
```markdown
As we discussed in [](#ch01-intro), the fundamentals are...
See [Figure {number}](#fig-ch02-diagram) from the previous chapter.
```

---

## Citations

### DOI Links (easiest)
```markdown
This was shown by [](https://doi.org/10.1234/example).
```
Auto-fetches citation data. No BibTeX needed.

### BibTeX
Add `references.bib` to project root, reference in `myst.yml`:
```yaml
project:
  bibliography:
    - references.bib
```

In text (Pandoc-style):
```markdown
@author2023 showed that...               — narrative: Author (2023)
[@author2023]                            — parenthetical: (Author, 2023)
[@author2023; @other2024]                — multiple
[see @author2023, chap. 3]              — with prefix/suffix
```

Or with roles:
```markdown
{cite:t}`author2023` showed that...      — textual
{cite:p}`author2023`                     — parenthetical
```

---

## Document Parts

```yaml
---
parts:
  abstract: |
    This chapter introduces the core concepts...
  data_availability: |
    All data is available at https://example.com/data
  acknowledgments: |
    Thanks to...
---
```

---

## Export Formats

In page frontmatter or `myst.yml`:
```yaml
exports:
  - format: pdf
    template: plain_latex_book
    output: exports/book.pdf
  - format: typst
    template: lapreprint-typst
    output: exports/book-typst.pdf
  - format: docx
    output: exports/book.docx
  - format: tex
    output: exports/latex/
  - format: meca
    output: exports/bundle.zip
```

Build: `myst build --pdf` or `myst build --docx` or `myst build --html`

---

## Best Practices for Book Chapters

1. **Always use frontmatter** — title, description, label, tags
2. **Label everything referenceable** — figures, tables, equations, sections, theorems
3. **Use consistent label prefixes** — `fig-`, `tbl-`, `eq-`, `ch-`, `thm-`, `def-`, `ex-`
4. **Put images in `images/`** — use relative paths: `../images/ch01-hero.png`
5. **One H1 per file** (the title) — start content at H2
6. **Use admonitions** for tips, warnings, important notes
7. **Use cross-references** liberally across chapters
8. **Include alt text** on all images for accessibility
9. **Use tabs** for showing same concept in multiple languages
10. **Use dropdowns** for supplementary/optional content
