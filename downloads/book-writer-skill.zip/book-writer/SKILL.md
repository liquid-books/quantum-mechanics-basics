---
name: book-writer
description: Creates and manages books in MyST Markdown (Jupyter Book) format. Takes an idea or chapter outline, writes chapters with rich formatting, generates images via NanoBanana Pro, tracks everything in Google Sheets, and deploys to GitHub Pages. Use when the user wants to create a book, write chapters, or manage book projects.
---

# Book Writer Agent

Orchestrates the full lifecycle of creating, writing, and deploying books using MyST Markdown.

## Dependencies

- **One illustrated explainer infographic** at the start of every chapter, covering its core concepts.
- **Official Book Cover** for every book, including the title and "Dr. Ernesto Lee" as the author.
- **Nano Banana Pro** (`google/gemini-3-pro-image-preview`) via OpenRouter for all image generation. Falls back to Nano Banana Flash (`google/gemini-3.1-flash-image-preview`) via OpenRouter if Pro fails. **FLUX is not used.**

### ⚠️ Book Cover Rules (NON-NEGOTIABLE)

**1. Always 100% width.** The cover figure in `index.md` MUST use `:width: 100%`. Never 55%, 60%, or any other value. The cover is the hero image — it should fill the full content column.

**2. Every cover must be unique to the book's subject matter.** Do NOT use generic tech imagery (glowing brains, circuit boards, abstract spheres, generic network nodes). The cover image must visually represent something *specific and recognizable* from the book's actual topic. Examples:
- Quantum computing book → real quantum hardware (dilution refrigerator, IBM cryostat)
- Supply chain book → an actual container port or logistics map
- AI/ML book → a specific real-world application scene, not a robot face
- Finance book → trading floor, financial instruments, or economic data visualization

**3. Always a 3D standing book mockup.** The cover image must be a photorealistic 3D book mockup standing upright on a white surface with a soft drop shadow, slight angle showing the spine. Portrait orientation. White background. NOT a flat 2D design.

**4. Cover prompt template (use this exact structure every time):**
```
A photorealistic 3D hardcover book mockup standing upright, centered, filling the entire frame.
The book is LARGE — portrait orientation, occupying 80-90% of the image height. Slight 3/4 angle
so both the front cover and left spine are clearly visible and readable. Pure white background
and pure white surface. Soft realistic drop shadow beneath the book.

The front cover features [UNIQUE SUBJECT-SPECIFIC VISUAL — something real, specific, and
recognizable from the book's actual topic. NOT glowing brains, NOT circuit boards, NOT abstract
spheres. Real hardware, real scenes, real objects that a reader would immediately connect to
the subject matter].

Title '[BOOK TITLE]' in large bold white uppercase letters at the top.
Subtitle in smaller gold or contrasting color below.
Author 'Dr. Ernesto Lee' in clean white font at the bottom.
Spine reads '[SHORT TITLE] • Dr. Ernesto Lee' in crisp white text on matching background.
Ultra-realistic product photography. Premium hardcover. High resolution.
```

**5. Cover in index.md must be the VERY FIRST element** — before the H1, before any text. The figure directive goes at the top of the file, immediately after the frontmatter `---`.

**6. Cover figure directive MUST use `:width: 100%` — always, no exceptions:**
```markdown
:::{figure} images/cover.png
:label: fig-cover
:alt: [Book title] cover by Dr. Ernesto Lee
:width: 100%
:align: center

*[Book Title]* · Dr. Ernesto Lee
:::
```

**7. Reference size/layout:** The cover should look like a large centered book product photo filling the full content column — portrait orientation, white background, like an Amazon listing. The `ai-business-innovation-grad` book is the gold standard for size and layout.

### ⚠️ Critical: OpenRouter Image Response Format
Gemini image models via OpenRouter do **NOT** return image data in `message.content` (it is always `null`). Images are returned in:
```
response.choices[0].message.images[0].image_url.url
```
This is a `data:image/jpeg;base64,...` string. The `generate-image.js` script handles this correctly — always use the script, never write custom image API calls.

## Scripts

| Script | Purpose |
|--------|---------|
| `scripts/scaffold-book.js` | Create disk structure, myst.yml, index.md, deploy workflow |
| `scripts/update-registry.js` | Google Sheets registry for books + chapters |
| `scripts/validate-chapter.js` | **MANDATORY** pre-commit validation — checks images, refs, format, TOC |
| `scripts/generate-image.js` | **MANDATORY** image generation — Node.js, auto-retry, uses FLUX.1 Pro via fal.ai |
| `scripts/generate-cover.js` | Generate a high-quality book cover with title and author |

## Book Registry

**Sheet ID:** Set by user on first use. Store in `/home/node/openclaw/books/.registry-sheet-id`

### Initialize
```bash
# Create a Google Sheet first
node scripts/google-sheets.js create "Book Registry"
# Then init with headers
node skills/book-writer/scripts/update-registry.js init <sheetId>
# Save the sheet ID
echo "<sheetId>" > /home/node/openclaw/books/.registry-sheet-id
```

## Workflows

### A. Create a New Book

1. Generate metadata from the idea: slug, title, author, chapter plan
2. Scaffold on disk:
   ```bash
   node skills/book-writer/scripts/scaffold-book.js <slug> "<title>" "<author>"
   ```
3. Generate the Book Cover:
   ```bash
   node skills/book-writer/scripts/generate-cover.js <slug> "<title>" "Dr. Ernesto Lee"
   ```
4. Create GitHub repo + push:
   ```bash
   node skills/github-books/scripts/github-api.js create-repo <slug> "<description>"
   node skills/github-books/scripts/github-api.js push /home/node/openclaw/books/<slug> <slug> "Initial scaffold and cover"
   node skills/github-books/scripts/github-api.js enable-pages <slug>
   ```
5. Register in Google Sheet:
   ```bash
   node skills/book-writer/scripts/update-registry.js add-book <sheetId> '<json>'
   ```
6. Report to user with GitHub Pages URL

### B. Write a Chapter

1. **Load context:** Read myst.yml, previous chapters (for continuity), and `references/myst-syntax-guide.md`
2. **Write the chapter** as a `.md` file in `chapters/`:
   - Full YAML frontmatter (title, subtitle, description, label, tags, etc.)
   - **Mandatory Infographic figure** at the top of the file (after H1).
   - Rich MyST syntax: admonitions, figures, code blocks, cross-refs, math, etc.
   - Figure placeholders with descriptive prompts
3. **Generate images** for each figure using FLUX.1 Pro:
   - **First image:** Generate the "Illustrated Explainer Infographic" (wide landscape).
   - Generate subsequent images as needed.
   - Save to `images/` folder
   - Update figure directives with actual file paths
- **Exports**: Enable PDF downloads in `myst.yml`. Add the following to the `project` section:
  ```yaml
  exports:
    - format: pdf
  ```
- **CI/CD Build**: Ensure the GitHub Actions workflow (`deploy.yml`) builds the PDFs using Typst and copies them to the HTML output:
  ```yaml
  - name: Build HTML and PDF Assets
    run: |
      myst build --html
      myst build --pdf --typst --all
      mkdir -p _build/html/exports
      find _build/exports -name "*.pdf" -exec cp {} _build/html/exports/ \; || true
  ```
- **Logo Link**: Ensure `logo_url` in `site.options` matches the GitHub Pages base path (e.g., `/<slug>/`) to avoid 404s.

### TOC and Numbering
- **Chapter Numbers**: Always include the chapter number AND title in the `myst.yml` TOC entries using both `title` and `file` keys (e.g., `- title: "Chapter 1: Introduction to AI in Business"
  file: chapters/ch01-intro.md`). This ensures the sidebar navigation shows "Chapter 1: ..." instead of just the page title.
- **Update myst.yml** TOC to include the new chapter.
- **Update index.md** — Add the new chapter to the Available Chapters grid on the book's landing page (`index.md`). This is mandatory — the index is what readers see first.
  - **CRITICAL:** Use an HTML placeholder like `<!-- GRID_PLACEHOLDER -->` inside the `:::{grid} 2` block to safely inject new chapters without breaking the MyST grid syntax.
   ```markdown
   :::{grid-item-card} Chapter N: Title
   :link: ./chapters/chNN-slug.md
   Brief one-line description.
   :::
   <!-- GRID_PLACEHOLDER -->
   ```
   {grid-item-card} Chapter N: Title
   :link: ./chapters/chNN-slug.md
   Brief one-line description.
   :::
   ```
5. **VALIDATE (mandatory, never skip):**
   ```bash
   node skills/book-writer/scripts/validate-chapter.js /home/node/openclaw/books/<slug> chapters/chXX-slug.md
   ```
   - If validation FAILS (exit code 1): **STOP. Fix all errors before continuing.** Do NOT commit or push with broken refs.
   - If validation passes (exit code 0): proceed to commit.
6. **Commit + push** to GitHub:
   ```bash
   cd /home/node/openclaw/books/<slug>
   git add -A
   git commit -m "Chapter N: <title>"
   node skills/github-books/scripts/github-api.js push /home/node/openclaw/books/<slug> <slug> "Chapter N: <title>"
   ```
   - The push script will verify local and remote are in sync after pushing.
   - If push output shows `"pushed": false`, that's a **FAILURE** — investigate and retry.
   - Always check the `pushed` and `success` fields in the JSON output.
7. **Verify push succeeded:**
   ```bash
   cd /home/node/openclaw/books/<slug>
   git log --oneline -1
   git status
   ```
   - `git status` must say "Your branch is up to date with 'origin/main'"
   - If it says "ahead of", the push failed — run `git push origin main` directly.
8. **Update registry:** chapter status, word count, image count

### Pre-Commit Checklist (MANDATORY — NEVER SKIP)

**Use the validation script.** This is not optional.

```bash
# Run for every chapter being committed:
node skills/book-writer/scripts/validate-chapter.js /home/node/openclaw/books/<slug> chapters/chXX-slug.md
```

The script checks:
1. ✅ All image references resolve to real files on disk
2. ✅ No markdown-style images (`![]()`); only MyST `:::{figure}` allowed
3. ✅ All images are PNG format
4. ✅ All images are >50KB (real NanoBanana Pro images are 300-800KB)
5. ✅ Chapter is listed in myst.yml TOC
6. ✅ Frontmatter has required fields (title, label, description)
7. ✅ Mandatory Infographic exists at the top of the chapter
8. ⚠️ Word count warning if below 8,000
9. ⚠️ Figure count warning if below 10

**Exit code 0** = passed → proceed to commit
**Exit code 1** = ERRORS found → **FIX BEFORE COMMITTING. DO NOT SKIP.**

After committing + pushing, also verify the push landed:
```bash
cd /home/node/openclaw/books/<slug>
git fetch origin main
git status
# MUST say "up to date with 'origin/main'"
# If "ahead of" → push failed, run: git push origin main
```

### C. Edit/Revise a Chapter

1. Read existing chapter from disk
2. Apply edits, regenerate images if needed
3. Update myst.yml if chapter title changed
4. Commit + push with descriptive message
5. Update registry (last_edited, word_count)

### D2. Google Colab Notebooks for Advanced Labs (MANDATORY FOR EVERY CHAPTER)

Every chapter with an Optional Advanced Python Lab MUST have a corresponding Jupyter notebook in the `notebooks/` folder and a clickable "Open in Colab" badge in the chapter.

**Why:** Students cannot be expected to set up local Python environments. Google Colab is free, browser-based, zero-install, and works on any device including Chromebooks. The notebook IS the lab — not a supplement to it.

#### Notebook File Location
```
/home/node/openclaw/books/<slug>/notebooks/chNN-lab-name.ipynb
```

#### Notebook Structure (every notebook must have these cells in order)
1. **Title cell (Markdown):** `# Chapter N Advanced Lab: [Lab Title]`
2. **Colab setup cell (Markdown):** Brief intro + link back to the book page
3. **Install cell (Code):** `!pip install -q <required packages>` — tagged with comment `# Run this first — takes ~30 seconds`
4. **Import cell (Code):** All imports
5. **Starter code cells:** Pre-written scaffolding with `# TODO:` comments where students fill in
6. **Deliverable cell (Markdown):** Clear statement of what to submit

#### "Open in Colab" Badge in Chapter
In the chapter `.md` file, at the start of the Optional Advanced Lab section, add the badge as raw HTML (MyST supports inline HTML):

```html
<a href="https://colab.research.google.com/github/liquid-books/<slug>/blob/main/notebooks/chNN-lab-name.ipynb" target="_blank">
  <img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab" style="margin-bottom: 1rem;"/>
</a>
```

Replace `<slug>` and `chNN-lab-name` with the actual values.

#### Creating the Notebook File
Write the `.ipynb` as valid JSON. Minimal structure:
```json
{
  "nbformat": 4,
  "nbformat_minor": 5,
  "metadata": {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.10.0"},
    "colab": {"provenance": []}
  },
  "cells": [
    {"cell_type": "markdown", "metadata": {}, "source": ["# Chapter N Advanced Lab: Title\n", "..."]},
    {"cell_type": "code", "execution_count": null, "metadata": {}, "outputs": [], "source": ["# Run this first\n", "!pip install -q qiskit pandas matplotlib\n"]}
  ]
}
```

#### After creating the notebook
- Add it to git, commit, and push with the chapter
- Verify the Colab URL works: `https://colab.research.google.com/github/liquid-books/<slug>/blob/main/notebooks/chNN-lab-name.ipynb`

### E. Final Landing Page Polish (MANDATORY AT END)

Once all chapters and appendices are written:
1. Generate a comprehensive, high-quality landing page for the book's `index.md`.
2. This page should act as a sales page/overview: it must include the book's core value proposition, the target audience, a summary of what students will learn, and the generated cover image `:::{figure} images/cover.png`.
3. Keep the "Available Chapters" grid at the bottom of the page.
4. Commit and push the final `index.md`.

```bash
cd /home/node/openclaw/books/<slug>
npx mystmd build --html
npx serve _build/html
```

## Quality Standards (LOCKED IN)

**Modern Case Studies (STRICT):** As of 2026, all case studies, examples, and use cases MUST be modern and up-to-date (reflecting 2025-2026 realities, current AI capabilities like agentic workflows, modern platforms, etc.). Do not use dated examples from the 2010s unless explicitly providing historical context.

Every chapter MUST meet these standards. No exceptions.

### ⚠️ NO EXERCISES OR QUIZZES IN THE CHAPTER (STRICT RULE)

**Exercises, quizzes, and multiple-choice questions do NOT belong in the chapter `.md` file.** They take up too much space, break reading flow, and clutter the book.

**Instead:**
- Create a SEPARATE file: `quizzes/chNN-quiz.md` in the book repo
- This file lives on GitHub for instructors to use, but is NOT included in the `myst.yml` TOC and will NOT appear in the published book
- The chapter itself contains ONLY: the Productive-Struggle Problem (one open-ended scenario), Discussion Guidelines, Labs, Glossary, and Leader's Takeaway

**Quiz file format** (`quizzes/chNN-quiz.md`):
```markdown
# Chapter N Quiz: [Title]
*Instructor resource — not published in the book.*

## Multiple Choice (10 questions)
...

## Short Answer (3 questions)
...

## Answer Key
...
```

### ⚠️ THE SECRET SAUCE: Plain-Language Concept Explanations (MANDATORY)

**This is the single most important quality standard in this book.** The target reader is a business leader with no physics background. If they need to already understand quantum computing to understand your explanation, you have failed.

**Every core concept MUST pass the "9th Grader Test":** Could a smart 14-year-old understand this explanation with zero prior physics knowledge? If not, rewrite it. Not dumbed down — just genuinely clear.

**The formula for every concept (MANDATORY — 5 steps, always in this order):**
1. **Start with something they already know** — a familiar object, financial instrument, daily experience, or business scenario
2. **Build the bridge** — show how that familiar thing maps onto the quantum concept
3. **Name the concept** — now introduce the technical term, anchored to the analogy
4. **Show where the analogy breaks down** — one honest sentence about its limits (this builds trust and credibility)
5. **Sell the revolution** — this is NOT optional. After the analogy lands, spend a full paragraph showing why this concept is *transformative*. What becomes possible that was impossible before? What industries does it reshape? What is the scale of the opportunity? Make the reader feel the weight of what they just understood. This is the moment the concept goes from "interesting" to "I need to bring this to my board."

**Analogy quality bar:** The analogy must be so clear that the reader can explain it back to a colleague at dinner without notes. If it requires a diagram to understand, it's not good enough yet.

**The "Sell the Revolution" standard:**
After every core concept explanation, there must be a passage that answers: *So what? Why should a CFO, board member, or strategy director care about this?* It should include:
- A specific real-world application or industry impact
- A sense of scale (dollars, years saved, problems now solvable)
- The before/after contrast — what was impossible before, what becomes possible now
- Emotional resonance — the reader should feel genuine excitement or urgency

**Examples of the standard to hit:**
- ❌ Weak: "Superposition is when a qubit exists in a combination of 0 and 1 states simultaneously."
- ✅ Strong analogy: "Imagine you're a hedge fund manager holding 1,000 different possible portfolios simultaneously — not committed to any one of them yet — waiting for new information before you collapse to a single position. That is superposition."
- ✅ Strong revolution sell: "Here is why this rewrites the economics of computation: today's most powerful drug-discovery supercomputers cannot simulate a molecule with more than about 50 atoms — the calculation becomes too complex. A fault-tolerant quantum computer using superposition could simulate molecules with thousands of atoms simultaneously. That capability sits at the heart of every blockbuster drug, every next-generation battery, every carbon-capture material we cannot yet design. The pharmaceutical industry alone spends \$2.6 billion per approved drug. Superposition is not an interesting physics trick. It is the reason Pfizer, Roche, and Merck are spending real money on quantum computing right now."

**Required depth for every core concept in any chapter:**
- At least one full paragraph of plain-language explanation (9th Grader Test)
- At least one concrete analogy from business, finance, or everyday life
- One honest sentence about where the analogy is imperfect
- One full paragraph selling the revolutionary value — specific, scaled, emotionally resonant

### Content Depth
- **Textbook-level writing**: Not overviews. Real depth with explanations, examples, and context
- **FLOOR: 6,500 words. HARD CAP: 8,000 words.** With exercises removed, use the freed space for richer concept explanations, deeper analogies, and more narrative case studies.
- **Application Cases**: 4-6 real-world cases per chapter, written as full narratives (not bullet summaries)
- **Worked examples**: At least one fully worked problem with step-by-step solution
- **Discussion questions**: Thought-provoking, not recall-based

**Mandatory Discussion Guidelines**: Every chapter MUST have a "Discussion Guidelines" block in its Discussion section that explicitly tells students:
- To include at least one scholarly or credible citation in their main response.
- To respond to at least TWO peers with substantial feedback (more than just "I agree").
**Negative Constraints for Discussions**: Do NOT mention "small-group debate", "groups of 3-4", "full-class debrief", "seminar format", or "in-class discussion". These are individual online assignments, not group or synchronous class activities.

### ⚠️ CRITICAL: Dollar Signs Before Numbers (KNOWN BUG — ALWAYS FIX)

MyST Markdown treats `$` as a math delimiter. Any `$` immediately followed by a digit (e.g. `$6 billion`, `$450B`, `$1.2 trillion`) will be parsed as inline LaTeX math and render as garbled italic text.

**Rule:** In all chapter body text, escape every dollar sign before a number: use `\$` not `$`.

✅ Correct: `\$850 billion`, `\$1.4 billion`, `\$450B–\$850B`
❌ Wrong: `$850 billion`, `$1.4 billion`, `$450B–$850B`

**Exception:** YAML frontmatter values (title, subtitle, description fields) do NOT need escaping — MyST does not parse math in frontmatter strings.

**Post-write check (run before validation):**
```bash
# Find any unescaped $DIGIT patterns in chapter body (skip frontmatter lines)
grep -n '(?<!\\)\$[0-9]' chapters/chXX-*.md
# Fix all at once:
perl -i -pe 's/(?<!\\)\$(?=[0-9])/\\\$/g unless $. <= 15' chapters/chXX-*.md
```

### MyST Feature Usage (USE ALL OF THESE)
- **Tabs**: For comparing 2+ concepts side by side (architectures, methodologies, tools)
- **Cards & Grids**: For visual groupings (characteristics, attributes, operations)
- **Dropdowns**: For supplementary deep-dives, solutions, optional detail
- **Mermaid diagrams**: For processes, flows, architectures, ER diagrams
- **Admonitions**: Mix of note, tip, warning, danger, important, seealso
- **Glossary**: 15+ defined terms per chapter
- **Tables**: Labeled and cross-referenceable, with proper headers
- **Figures**: Generated via Nano Banana Pro (`google/gemini-3-pro-image-preview`) via OpenRouter using `generate-image.js`, with labels, alt text, captions
- **Cross-references**: Label everything; reference across chapters
- **Epigraphs**: Opening quotes where fitting
- **Code blocks**: With language, line numbers, captions, emphasis-lines
- **prf:definition**: For formal definitions of key concepts

### Branding
- **Author**: Dr. Ernesto Lee (no affiliations in frontmatter)
- **Sidebar footer**: "Made by DrLee.ai" (via primary-sidebar-footer.md)
- **Site title**: Book title (not "Made with MyST")
- **Logo text**: Book title
- **TOC**: Chapter numbers via title grouping in myst.yml

## Chapter Writing Guidelines

When writing a chapter, follow these rules:

### Structure
- **Text Generation Model:** Always use **Claude 4.6 Sonnet** for generating chapter text to ensure natural, high-quality academic prose that avoids robotic AI cliches.
- **Handling Token Limits (MANDATORY):** Claude 4.6 Sonnet has an 8192 token output limit. When generating long ~7,000 word chapters, it WILL hit `stop_reason: "max_tokens"`. You MUST write a loop in your generation function that detects this and automatically appends `"Continue exactly from where you left off. Do not repeat anything. Just continue the next word."` as a user message, stitching the responses together. Do not allow chapters to be truncated.
- **TOC and Index Updates:** When adding to `myst.yml`, ensure you append to the very end of the `toc:` list, keeping proper indentation (`    - file:` and `      title:`). When updating `index.md`, use a `<!-- GRID_PLACEHOLDER -->` marker inside the `:::{grid} 2` block to inject new `:::{grid-item-card}` components safely without destroying the document.
- One H1 (the title from frontmatter)
- **Immediately following the H1**, include an "Illustrated Explainer Infographic" figure summarizing the chapter.
- Use H2 for major sections, H3 for subsections, H4 sparingly
- Include an intro paragraph before the first H2

### Required Frontmatter (Chapter-Level)
```yaml
---
title: "Chapter Title"
subtitle: "Optional"
short_title: "Nav Title"
description: "Brief summary"
label: ch-XX-slug
tags: [relevant, tags]
---
```

### Figures — CONSISTENCY RULES (STRICT)

**Format:** ALL images MUST be PNG. No JPG, no SVG, no other formats. PNG only.

**Generation:** ALL images MUST be generated via FLUX.1 Pro (fal.ai). Never create placeholder SVGs, never use other models, never use markdown image syntax.

**Syntax:** ONLY use MyST figure directives. NEVER use markdown image syntax (`![alt](path)`).

```markdown
:::{figure} ../images/chXX-descriptive-name.png
:label: fig-chXX-descriptive-name
:alt: Clear description of what the image shows
:width: 80%
:align: center

Descriptive caption explaining the figure's relevance to the chapter content.
:::
```

**Naming:** `images/chXX-descriptive-name.png` (e.g., `ch04-crisp-dm-cycle.png`)

**Required attributes:** label, alt, width (80% default), align (center), caption text.

**Per chapter:** Generate 10 images. Every figure directive MUST have a corresponding real PNG file.

**Infographic Style (Mandatory for first image):**
- Prompt MUST include: "A professional, comprehensive explainer infographic summarizing the concepts of [Chapter Topic]. Clean modern flat design, blue and orange color scheme. Clear typography, icons, and flowchart elements. Textbook quality, 16:9 landscape format."

**Visual consistency:** Every image prompt MUST include these style keywords:
- "Professional textbook illustration"
- "Clean modern infographic style"  
- "Blue and orange color scheme with gray accents"
- "White or light background"
- "Labeled components with clear typography"
- "Business analytics / data science education context"
- "Wide landscape format, high resolution"

**Verification step:** After writing a chapter, run this check before committing:
```bash
# Verify all figure references have matching files
for f in $(grep -oP '\.\./images/[^\s\)]+' chapters/chXX-*.md); do
  ref="${f#../}"
  [ ! -f "$ref" ] && echo "BROKEN: $f"
done
```
If any are broken, fix them before committing. Never commit broken image references.

### Formatting
- Use `:::{note}`, `:::{tip}`, `:::{warning}` for callouts
- Use `:::{dropdown}` for supplementary content
- Use code blocks with language + line numbers for code
- Use tabs for multi-language examples
- Use cross-references `[](#label)` between chapters
- Use math notation for formulas: `$inline$` and `$$display$$`
- Use mermaid diagrams for flowcharts/processes

### Large Chapter Handling & Continuation (MANDATORY)
- **Token Limits:** Modern LLMs (like Claude 4.6 Sonnet) have hard output token limits (e.g., 8,192 tokens). Because chapters are long (~7,000 words), a single request will often cut off midway through.
- **Auto-Continuation:** Your builder script MUST implement a loop to check the API response for a stop reason (e.g., `stop_reason === "max_tokens"` or incomplete block). If it hits the limit, append the partial response, and send a follow-up prompt: `"Continue exactly from where you left off. Do not repeat anything. Just continue the next word."` Keep looping until the chapter finishes normally.

### Image Generation (FLUX.1 Pro) — MANDATORY PROCESS

**USE THE SCRIPT. Do not write your own image generation code.**

```bash
node skills/book-writer/scripts/generate-image.js <output-path> "<prompt>"
```

Example:
```bash
node /home/node/openclaw/skills/book-writer/scripts/generate-image.js \
  /home/node/openclaw/books/my-book/images/ch01-diagram.png \
  "Professional textbook illustration of a data pipeline architecture. Clean modern infographic style. Blue and orange color scheme with gray accents. White background. Labeled components with clear typography. Business analytics education context. Wide landscape format, high resolution."
```

The script:
- Uses Node.js (guaranteed to work in this environment — **do NOT use Python**)
- Tries `gemini-3.1-flash-image-preview` first with 1 retry
- Falls back to `gemini-3-pro-image-preview` on persistent errors
- Verifies output is >50KB (rejects placeholder-sized results)
- Outputs JSON with `success`, `path`, `size`, `model` used
- Exit code 0 = success, 1 = failure

**For each figure:**
1. Write a detailed prompt with the **mandatory style keywords** (see Figures section)
2. Run the generate-image.js script
3. Check the JSON output for `"success": true`
4. If failed, check the error and retry or report

**NEVER:**
- Write your own image generation code (Python, curl, etc.) — always use the script
- Create SVG/text placeholders instead of generating real images
- Use markdown image syntax (`![]()`); always use MyST `:::{figure}` directives
- Commit without verifying all image files exist on disk
- Skip the style keywords (they ensure cross-chapter visual consistency)

## File Layout

```
/home/node/openclaw/books/<slug>/
├── .git/
├── .github/workflows/deploy.yml
├── .gitignore
├── myst.yml
├── references.bib         (optional)
├── index.md               (Landing page with Book Cover and Chapter Grid)
├── chapters/
│   ├── ch01-slug.md
│   ├── ch02-slug.md
│   └── ...
└── images/
    ├── cover.png          (Official Book Cover)
    ├── ch01-hero.png
    ├── ch01-diagram.png
    └── ...
```

## Failure Handling (STRICT — NO SILENT FAILURES)

**Every step must be verified.** If any step fails, STOP and report the error. Never continue past a failure.

### Image Generation
- After generating each image, verify the file exists and is >50KB
- If the API returns an error or empty response, retry once. If it fails again, report the error.
- Never create SVG/text placeholders as a substitute for real generated images
- Never commit a chapter that references images that don't exist

### Git Push
- After running the push script, check the JSON output for `"pushed": true`
- If `"pushed": false` and there are local commits ahead of remote, the push FAILED
- Run `git status` after push to verify "up to date with 'origin/main'"
- If push failed, run `git push origin main` directly and check exit code

### Registry Update
- After adding to Google Sheets, verify the response contains `"success": true`
- If it fails, retry once. If still failing, report but don't block the chapter.

### Validation
- Always run `validate-chapter.js` before committing
- If it returns exit code 1, fix ALL errors before proceeding
- Warnings are acceptable but should be noted in the report

### Error Reporting
When reporting results back, ALWAYS include:
- ✅ or ❌ for each step (image gen, validation, commit, push, registry)
- File sizes for generated images
- Git status output confirming push
- Any errors encountered, even if recovered from

## Book-Level vs Chapter-Level Attributes

### Book-Level (in myst.yml → project)
- title, subtitle, authors, description
- license, copyright, doi, github
- keywords, subject, bibliography
- numbering config (figure, table, equation, heading levels)
- math macros (shared across all chapters)
- abbreviations (shared across all chapters)
- toc (table of contents — all chapters)
- exports (PDF, DOCX, etc.)

### Chapter-Level (in page frontmatter)
- title, subtitle, short_title, description
- label (for cross-referencing)
- tags, keywords
- date, authors (can override project)
- thumbnail, banner
- parts (abstract, etc.)
- numbering (can override project)
- math macros (chapter-specific, adds to project)
- exports (chapter-specific export config)
