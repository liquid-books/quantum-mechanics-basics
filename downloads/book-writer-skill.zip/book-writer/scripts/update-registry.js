#!/usr/bin/env node
/**
 * Book Registry — Google Sheets interface for tracking books and chapters
 *
 * Usage: node update-registry.js <command> [args...]
 *
 * Commands:
 *   init <sheetId>                                   Initialize registry with headers
 *   add-book <sheetId> <bookJson>                    Add a book entry
 *   update-book <sheetId> <bookId> <field> <value>   Update a book field
 *   add-chapter <sheetId> <chapterJson>              Add a chapter entry
 *   update-chapter <sheetId> <bookId> <chNum> <field> <value>  Update a chapter field
 *   get-book <sheetId> <bookId>                      Get a book's details
 *   get-chapters <sheetId> <bookId>                  Get all chapters for a book
 *   list-books <sheetId>                             List all books
 */

const { getAuth, google } = require('/home/node/openclaw/scripts/google-auth');

const auth = getAuth();
const sheets = google.sheets({ version: 'v4', auth });

// Sheet names
const BOOKS_SHEET = 'Books';
const CHAPTERS_SHEET = 'Chapters';

// Book columns
const BOOK_HEADERS = [
  'book_id', 'title', 'authors', 'description', 'status',
  'github_repo', 'pages_url', 'disk_path', 'total_chapters',
  'created', 'last_updated',
  // Book-level MyST attributes
  'license', 'keywords', 'subject', 'doi',
];

// Chapter columns
const CHAPTER_HEADERS = [
  'book_id', 'chapter_num', 'title', 'status', 'file_path',
  'image_count', 'word_count', 'created', 'last_edited', 'outline',
  // Chapter-level MyST attributes
  'subtitle', 'description', 'tags', 'label',
];

const commands = {
  async init(sheetId) {
    // Create Books sheet with headers
    try {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId: sheetId,
        requestBody: {
          requests: [
            { addSheet: { properties: { title: BOOKS_SHEET } } },
            { addSheet: { properties: { title: CHAPTERS_SHEET } } },
          ]
        }
      });
    } catch (e) {
      // Sheets may already exist
    }

    // Write headers
    await sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: `${BOOKS_SHEET}!A1`,
      valueInputOption: 'RAW',
      requestBody: { values: [BOOK_HEADERS] },
    });

    await sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: `${CHAPTERS_SHEET}!A1`,
      valueInputOption: 'RAW',
      requestBody: { values: [CHAPTER_HEADERS] },
    });

    console.log(JSON.stringify({
      success: true,
      message: 'Registry initialized',
      book_headers: BOOK_HEADERS,
      chapter_headers: CHAPTER_HEADERS,
    }, null, 2));
  },

  async 'add-book'(sheetId, bookJson) {
    const book = JSON.parse(bookJson);
    const row = BOOK_HEADERS.map(h => book[h] || '');
    // Set created + last_updated if not provided
    const now = new Date().toISOString().split('T')[0];
    const createdIdx = BOOK_HEADERS.indexOf('created');
    const updatedIdx = BOOK_HEADERS.indexOf('last_updated');
    if (!row[createdIdx]) row[createdIdx] = now;
    if (!row[updatedIdx]) row[updatedIdx] = now;

    await sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: `${BOOKS_SHEET}!A:A`,
      valueInputOption: 'RAW',
      requestBody: { values: [row] },
    });

    console.log(JSON.stringify({ success: true, action: 'add-book', book_id: book.book_id }));
  },

  async 'update-book'(sheetId, bookId, field, value) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: `${BOOKS_SHEET}!A:${String.fromCharCode(65 + BOOK_HEADERS.length - 1)}`,
    });
    const rows = res.data.values || [];
    const colIdx = BOOK_HEADERS.indexOf(field);
    if (colIdx === -1) throw new Error(`Unknown field: ${field}`);

    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === bookId) {
        const cell = `${BOOKS_SHEET}!${String.fromCharCode(65 + colIdx)}${i + 1}`;
        await sheets.spreadsheets.values.update({
          spreadsheetId: sheetId,
          range: cell,
          valueInputOption: 'RAW',
          requestBody: { values: [[value]] },
        });
        // Also update last_updated
        const updatedCol = `${BOOKS_SHEET}!${String.fromCharCode(65 + BOOK_HEADERS.indexOf('last_updated'))}${i + 1}`;
        await sheets.spreadsheets.values.update({
          spreadsheetId: sheetId,
          range: updatedCol,
          valueInputOption: 'RAW',
          requestBody: { values: [[new Date().toISOString().split('T')[0]]] },
        });
        console.log(JSON.stringify({ success: true, action: 'update-book', book_id: bookId, field, value }));
        return;
      }
    }
    throw new Error(`Book not found: ${bookId}`);
  },

  async 'add-chapter'(sheetId, chapterJson) {
    const ch = JSON.parse(chapterJson);
    const row = CHAPTER_HEADERS.map(h => ch[h] || '');
    const now = new Date().toISOString().split('T')[0];
    const createdIdx = CHAPTER_HEADERS.indexOf('created');
    const editedIdx = CHAPTER_HEADERS.indexOf('last_edited');
    if (!row[createdIdx]) row[createdIdx] = now;
    if (!row[editedIdx]) row[editedIdx] = now;

    await sheets.spreadsheets.values.append({
      spreadsheetId: sheetId,
      range: `${CHAPTERS_SHEET}!A:A`,
      valueInputOption: 'RAW',
      requestBody: { values: [row] },
    });

    console.log(JSON.stringify({
      success: true, action: 'add-chapter',
      book_id: ch.book_id, chapter_num: ch.chapter_num, title: ch.title,
    }));
  },

  async 'update-chapter'(sheetId, bookId, chapterNum, field, value) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: `${CHAPTERS_SHEET}!A:${String.fromCharCode(65 + CHAPTER_HEADERS.length - 1)}`,
    });
    const rows = res.data.values || [];
    const colIdx = CHAPTER_HEADERS.indexOf(field);
    if (colIdx === -1) throw new Error(`Unknown field: ${field}`);

    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === bookId && rows[i][1] === String(chapterNum)) {
        const cell = `${CHAPTERS_SHEET}!${String.fromCharCode(65 + colIdx)}${i + 1}`;
        await sheets.spreadsheets.values.update({
          spreadsheetId: sheetId,
          range: cell,
          valueInputOption: 'RAW',
          requestBody: { values: [[value]] },
        });
        // Update last_edited
        const editedCol = `${CHAPTERS_SHEET}!${String.fromCharCode(65 + CHAPTER_HEADERS.indexOf('last_edited'))}${i + 1}`;
        await sheets.spreadsheets.values.update({
          spreadsheetId: sheetId,
          range: editedCol,
          valueInputOption: 'RAW',
          requestBody: { values: [[new Date().toISOString().split('T')[0]]] },
        });
        console.log(JSON.stringify({
          success: true, action: 'update-chapter',
          book_id: bookId, chapter_num: chapterNum, field, value,
        }));
        return;
      }
    }
    throw new Error(`Chapter not found: ${bookId} ch${chapterNum}`);
  },

  async 'get-book'(sheetId, bookId) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: `${BOOKS_SHEET}!A:${String.fromCharCode(65 + BOOK_HEADERS.length - 1)}`,
    });
    const rows = res.data.values || [];
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === bookId) {
        const obj = {};
        BOOK_HEADERS.forEach((h, idx) => obj[h] = rows[i][idx] || '');
        console.log(JSON.stringify(obj, null, 2));
        return;
      }
    }
    console.log(JSON.stringify({ error: true, message: `Book not found: ${bookId}` }));
  },

  async 'get-chapters'(sheetId, bookId) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: `${CHAPTERS_SHEET}!A:${String.fromCharCode(65 + CHAPTER_HEADERS.length - 1)}`,
    });
    const rows = res.data.values || [];
    const chapters = [];
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === bookId) {
        const obj = {};
        CHAPTER_HEADERS.forEach((h, idx) => obj[h] = rows[i][idx] || '');
        chapters.push(obj);
      }
    }
    console.log(JSON.stringify(chapters, null, 2));
  },

  async 'list-books'(sheetId) {
    const res = await sheets.spreadsheets.values.get({
      spreadsheetId: sheetId,
      range: `${BOOKS_SHEET}!A:${String.fromCharCode(65 + BOOK_HEADERS.length - 1)}`,
    });
    const rows = res.data.values || [];
    const books = [];
    for (let i = 1; i < rows.length; i++) {
      const obj = {};
      BOOK_HEADERS.forEach((h, idx) => obj[h] = rows[i][idx] || '');
      books.push(obj);
    }
    console.log(JSON.stringify(books, null, 2));
  },
};

async function main() {
  const [,, command, ...args] = process.argv;
  if (!command || !commands[command]) {
    console.log('Book Registry CLI\n');
    console.log('Commands:');
    console.log('  init <sheetId>');
    console.log('  add-book <sheetId> <bookJson>');
    console.log('  update-book <sheetId> <bookId> <field> <value>');
    console.log('  add-chapter <sheetId> <chapterJson>');
    console.log('  update-chapter <sheetId> <bookId> <chNum> <field> <value>');
    console.log('  get-book <sheetId> <bookId>');
    console.log('  get-chapters <sheetId> <bookId>');
    console.log('  list-books <sheetId>');
    process.exit(1);
  }
  try {
    await commands[command](...args);
  } catch (err) {
    console.error(JSON.stringify({ error: true, message: err.message }));
    process.exit(1);
  }
}

main();
