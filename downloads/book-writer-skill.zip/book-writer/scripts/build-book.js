#!/usr/bin/env node
/**
 * Build a MyST book locally
 * Usage: node build-book.js <book-slug> [--html|--pdf|--docx]
 *
 * Runs `npx mystmd build` in the book directory.
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const BOOKS_DIR = '/home/node/openclaw/books';

function build(bookSlug, format = '--html') {
  const bookDir = path.join(BOOKS_DIR, bookSlug);

  if (!fs.existsSync(bookDir)) {
    console.error(JSON.stringify({ error: true, message: `Book not found: ${bookDir}` }));
    process.exit(1);
  }

  if (!fs.existsSync(path.join(bookDir, 'myst.yml'))) {
    console.error(JSON.stringify({ error: true, message: 'No myst.yml found — is this a MyST project?' }));
    process.exit(1);
  }

  console.log(`Building ${bookSlug} with format: ${format}`);

  try {
    const output = execSync(`npx mystmd build ${format}`, {
      cwd: bookDir,
      encoding: 'utf8',
      stdio: 'pipe',
      timeout: 120000, // 2 min timeout
    });
    console.log(output);
    console.log(JSON.stringify({
      success: true,
      book: bookSlug,
      format,
      output_dir: path.join(bookDir, '_build'),
    }));
  } catch (err) {
    console.error(JSON.stringify({
      error: true,
      message: 'Build failed',
      stderr: err.stderr?.substring(0, 2000),
      stdout: err.stdout?.substring(0, 2000),
    }));
    process.exit(1);
  }
}

const [,, slug, format] = process.argv;
if (!slug) {
  console.log('Usage: node build-book.js <book-slug> [--html|--pdf|--docx]');
  process.exit(1);
}
build(slug, format || '--html');
