#!/usr/bin/env node
/**
 * Validate a chapter before committing
 * Checks for broken image refs, wrong formats, placeholder images, markdown images, TOC entry
 *
 * Usage: node validate-chapter.js <book-path> <chapter-file>
 * Example: node validate-chapter.js /home/node/openclaw/books/business-intelligence chapters/ch04-predictive-analytics-data-mining.md
 *
 * Exit code 0 = all checks passed
 * Exit code 1 = failures found (details printed to stdout as JSON)
 */

const fs = require('fs');
const path = require('path');
const yaml = require ? null : null; // We'll parse myst.yml manually

const MIN_IMAGE_SIZE = 50000; // 50KB minimum for real generated images
const ALLOWED_IMAGE_EXT = '.png';

function main() {
  const [,, bookPath, chapterFile] = process.argv;
  
  if (!bookPath || !chapterFile) {
    console.error('Usage: node validate-chapter.js <book-path> <chapter-file>');
    console.error('Example: node validate-chapter.js /path/to/book chapters/ch04-slug.md');
    process.exit(1);
  }

  const absBookPath = path.resolve(bookPath);
  const absChapterPath = path.join(absBookPath, chapterFile);
  const errors = [];
  const warnings = [];

  // 1. Check chapter file exists
  if (!fs.existsSync(absChapterPath)) {
    errors.push({ check: 'file-exists', message: `Chapter file not found: ${absChapterPath}` });
    printResult(errors, warnings);
    process.exit(1);
  }

  const content = fs.readFileSync(absChapterPath, 'utf8');
  const lines = content.split('\n');

  // 2. Check for markdown-style images (FORBIDDEN)
  const mdImageRegex = /!\[([^\]]*)\]\(([^)]*images[^)]*)\)/;
  lines.forEach((line, idx) => {
    const match = line.match(mdImageRegex);
    if (match) {
      errors.push({
        check: 'no-markdown-images',
        line: idx + 1,
        message: `Markdown image syntax found (use :::{figure} instead): ${match[0]}`,
        ref: match[2],
      });
    }
  });

  // 3. Check all image references resolve to real files
  const figureRefRegex = /\.\.\/(images\/[^\s\)\"']+)/g;
  const imageRefs = new Set();
  let match;
  while ((match = figureRefRegex.exec(content)) !== null) {
    imageRefs.add(match[1]);
  }

  for (const ref of imageRefs) {
    const absRef = path.join(absBookPath, ref);
    
    // Check file exists
    if (!fs.existsSync(absRef)) {
      errors.push({
        check: 'image-exists',
        message: `Image file not found: ${ref}`,
        path: absRef,
      });
      continue;
    }

    // Check file extension
    const ext = path.extname(ref).toLowerCase();
    if (ext !== ALLOWED_IMAGE_EXT) {
      errors.push({
        check: 'image-format',
        message: `Wrong image format: ${ref} (${ext}, must be ${ALLOWED_IMAGE_EXT})`,
      });
    }

    // Check file size (must be real, not placeholder)
    const stat = fs.statSync(absRef);
    if (stat.size < MIN_IMAGE_SIZE) {
      errors.push({
        check: 'image-size',
        message: `Image too small (likely placeholder): ${ref} (${stat.size} bytes, minimum ${MIN_IMAGE_SIZE})`,
        size: stat.size,
      });
    }
  }

  // 4. Check chapter is in myst.yml TOC
  const mystPath = path.join(absBookPath, 'myst.yml');
  if (fs.existsSync(mystPath)) {
    const mystContent = fs.readFileSync(mystPath, 'utf8');
    if (!mystContent.includes(chapterFile)) {
      errors.push({
        check: 'toc-entry',
        message: `Chapter not found in myst.yml TOC: ${chapterFile}`,
      });
    }
  } else {
    warnings.push({ check: 'myst-exists', message: 'myst.yml not found' });
  }

  // 5. Check frontmatter exists
  if (!content.startsWith('---')) {
    errors.push({
      check: 'frontmatter',
      message: 'Chapter is missing YAML frontmatter (must start with ---)',
    });
  } else {
    const fmEnd = content.indexOf('---', 3);
    if (fmEnd === -1) {
      errors.push({ check: 'frontmatter', message: 'Frontmatter not properly closed (missing closing ---)' });
    } else {
      const fm = content.substring(3, fmEnd);
      // Check required fields
      const requiredFields = ['title', 'label', 'description'];
      for (const field of requiredFields) {
        if (!fm.includes(`${field}:`)) {
          errors.push({
            check: 'frontmatter-field',
            message: `Missing required frontmatter field: ${field}`,
          });
        }
      }
    }
  }

  // 6. Check word count
  const bodyStart = content.indexOf('---', 3);
  const body = bodyStart > 0 ? content.substring(bodyStart + 3) : content;
  const wordCount = body.split(/\s+/).filter(w => w.length > 0).length;
  if (wordCount < 10000) {
    warnings.push({
      check: 'word-count',
      message: `Word count is ${wordCount} (target: 12,000+)`,
      wordCount,
    });
  }

  // 7. Check figure count
  const figureCount = (content.match(/:::{figure}|::::{figure}/g) || []).length;
  if (figureCount < 3) {
    warnings.push({
      check: 'figure-count',
      message: `Only ${figureCount} figures found (target: 3-5)`,
      figureCount,
    });
  }

  printResult(errors, warnings, { wordCount, figureCount, imageRefs: [...imageRefs] });
  process.exit(errors.length > 0 ? 1 : 0);
}

function printResult(errors, warnings, stats = {}) {
  const passed = errors.length === 0;
  console.log(JSON.stringify({
    passed,
    errors: errors.length,
    warnings: warnings.length,
    errorDetails: errors,
    warningDetails: warnings,
    stats,
    summary: passed
      ? `✅ All checks passed (${stats.wordCount || '?'} words, ${stats.figureCount || '?'} figures, ${(stats.imageRefs || []).length} images)`
      : `❌ ${errors.length} error(s) found — fix before committing`,
  }, null, 2));
}

main();
